var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_tG){self.testPort=td_tG.data[0];self.PortTestTimeOut=td_tG.data[1];td_hb();});var td_eI=function(td_xn){postMessage([self.OPEN,self.testPort]);};var td_nc=function(td_fx){var td_FF=td_j()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_FF]);};var td_cv=function(td_fa){var td_IQ=td_j()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_IQ]);};function td_hb(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_eI;self.localWs.onerror=td_nc;self.localWs.onclose=td_cv;self.localStartTime=td_j();setTimeout(td_O7,5);}catch(td_yM){tmx.debug(self.ERROR+self.SEP+td_yM.message);
}}function td_O7(){var td_G1=td_j()-self.localStartTime;if(self.localWs.readyState===0){if(td_G1>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_be();}else{setTimeout(function(){td_O7();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_G1]);td_be();}}function td_be(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_j(){return Date.now();}
