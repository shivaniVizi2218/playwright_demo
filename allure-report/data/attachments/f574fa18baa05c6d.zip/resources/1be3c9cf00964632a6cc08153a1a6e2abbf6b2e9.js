var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_cJ){self.testPort=td_cJ.data[0];self.PortTestTimeOut=td_cJ.data[1];td_zg();});var td_kF=function(td_kc){postMessage([self.OPEN,self.testPort]);};var td_gk=function(td_sE){var td_ad=td_d()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_ad]);};var td_oA=function(td_Y7){var td_Ha=td_d()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_Ha]);};function td_zg(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_kF;self.localWs.onerror=td_gk;self.localWs.onclose=td_oA;self.localStartTime=td_d();setTimeout(td_P5,5);}catch(td_bx){tmx.debug(self.ERROR+self.SEP+td_bx.message);
}}function td_P5(){var td_Pn=td_d()-self.localStartTime;if(self.localWs.readyState===0){if(td_Pn>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_E6();}else{setTimeout(function(){td_P5();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_Pn]);td_E6();}}function td_E6(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_d(){return Date.now();}
