var tmx = tmx || {}; //namespace
self.POSTMSGDONE = "DONE";
self.POSTMSGQUERY = "QUERY";
self.INIT = "INIT";
self.RESULT = "RESULT";
self.DATACOUNT = "DATACOUNT";
self.CTIMEOUT = "TIMEOUT";
self.MESSAGE = "message";
self.WOPEN = "watcher_open";
self.WERROR = "watcher_error";
self.WCLOSE = "watcher_close";
self.INTERVAL = "_interval";
self.NUMBER = "number";
self.SOCKET = "wss://127.0.0.1:";

self.pstMsg=null;self.isDone=false;self.count=-1;self.time=null;self.timeOut=5000;self.logFunc=null;self.addEventListener(self.MESSAGE,function(td_pw){switch(td_pw.data[0]){case self.INIT:self.count=td_pw.data[1];
self.time=td_j();if(typeof(td_pw.data[2])===self.NUMBER){self.timeOut=td_pw.data[2];}break;case self.RESULT:if((td_pw.data[1]<0)||(td_pw.data[1]>=self.count)){self.isDone=true;postMessage([self.POSTMSGDONE,self.DATACOUNT]);
}else{if((self.time+self.timeOut)<td_j()){self.isDone=true;postMessage([self.POSTMSGDONE,self.CTIMEOUT]);}}break;default:break;}if(self.isDone===false){setTimeout(function(){},100);postMessage([self.POSTMSGQUERY]);
}});var td_GN=function(td_Ny){postMessage([self.WOPEN,td_Ny.toString()]);};var td_DB=function(td_eL){postMessage([self.WERROR,td_eL.toString()]);};var td_BF=function(td_vc){postMessage([self.WCLOSE,td_vc.toString()]);
};
tmx.debug = function(){}

tmx.trace = function(){}

function td_j(){return Date.now();}
