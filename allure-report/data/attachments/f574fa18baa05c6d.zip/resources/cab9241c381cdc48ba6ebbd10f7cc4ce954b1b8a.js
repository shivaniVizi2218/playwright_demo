var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_XZ){self.testPort=td_XZ.data[0];self.PortTestTimeOut=td_XZ.data[1];td_Uq();});var td_Or=function(td_Po){postMessage([self.OPEN,self.testPort]);};var td_Y0=function(td_ev){var td_EQ=td_O()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_EQ]);};var td_Lp=function(td_hP){var td_d9=td_O()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_d9]);};function td_Uq(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_Or;self.localWs.onerror=td_Y0;self.localWs.onclose=td_Lp;self.localStartTime=td_O();setTimeout(td_mV,5);}catch(td_cy){tmx.debug(self.ERROR+self.SEP+td_cy.message);
}}function td_mV(){var td_l0=td_O()-self.localStartTime;if(self.localWs.readyState===0){if(td_l0>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_jE();}else{setTimeout(function(){td_mV();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_l0]);td_jE();}}function td_jE(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_O(){return Date.now();}
