var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_iD){self.testPort=td_iD.data[0];self.PortTestTimeOut=td_iD.data[1];td_uQ();});var td_tK=function(td_QX){postMessage([self.OPEN,self.testPort]);};var td_Z8=function(td_TU){var td_SY=td_L()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_SY]);};var td_Jr=function(td_IC){var td_WF=td_L()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_WF]);};function td_uQ(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_tK;self.localWs.onerror=td_Z8;self.localWs.onclose=td_Jr;self.localStartTime=td_L();setTimeout(td_Bp,5);}catch(td_ep){tmx.debug(self.ERROR+self.SEP+td_ep.message);
}}function td_Bp(){var td_YC=td_L()-self.localStartTime;if(self.localWs.readyState===0){if(td_YC>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_Qw();}else{setTimeout(function(){td_Bp();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_YC]);td_Qw();}}function td_Qw(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_L(){return Date.now();}
