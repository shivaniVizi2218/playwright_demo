var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_sV){self.testPort=td_sV.data[0];self.PortTestTimeOut=td_sV.data[1];td_uu();});var td_ow=function(td_CC){postMessage([self.OPEN,self.testPort]);};var td_Ec=function(td_g5){var td_sU=td_P()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_sU]);};var td_Mo=function(td_Pv){var td_rs=td_P()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_rs]);};function td_uu(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_ow;self.localWs.onerror=td_Ec;self.localWs.onclose=td_Mo;self.localStartTime=td_P();setTimeout(td_KU,5);}catch(td_xX){tmx.debug(self.ERROR+self.SEP+td_xX.message);
}}function td_KU(){var td_Nr=td_P()-self.localStartTime;if(self.localWs.readyState===0){if(td_Nr>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_Yk();}else{setTimeout(function(){td_KU();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_Nr]);td_Yk();}}function td_Yk(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_P(){return Date.now();}
