var tmx = tmx || {}; //namespace
self.POSTMSGDONE = "DONE";
self.POSTMSGQUERY = "QUERY";
self.INIT = "INIT";
self.RESULT = "RESULT";
self.DATACOUNT = "DATACOUNT";
self.CTIMEOUT = "TIMEOUT";
self.MESSAGE = "message";
self.WOPEN = "watcher_open";
self.WERROR = "watcher_error";
self.WCLOSE = "watcher_close";
self.INTERVAL = "_interval";
self.NUMBER = "number";
self.SOCKET = "wss://127.0.0.1:";

self.pstMsg=null;self.isDone=false;self.count=-1;self.time=null;self.timeOut=5000;self.logFunc=null;self.addEventListener(self.MESSAGE,function(td_Gz){switch(td_Gz.data[0]){case self.INIT:self.count=td_Gz.data[1];
self.time=td_G();if(typeof(td_Gz.data[2])===self.NUMBER){self.timeOut=td_Gz.data[2];}break;case self.RESULT:if((td_Gz.data[1]<0)||(td_Gz.data[1]>=self.count)){self.isDone=true;postMessage([self.POSTMSGDONE,self.DATACOUNT]);
}else{if((self.time+self.timeOut)<td_G()){self.isDone=true;postMessage([self.POSTMSGDONE,self.CTIMEOUT]);}}break;default:break;}if(self.isDone===false){setTimeout(function(){},100);postMessage([self.POSTMSGQUERY]);
}});var td_WI=function(td_ra){postMessage([self.WOPEN,td_ra.toString()]);};var td_tO=function(td_E3){postMessage([self.WERROR,td_E3.toString()]);};var td_ad=function(td_AP){postMessage([self.WCLOSE,td_AP.toString()]);
};
tmx.debug = function(){}

tmx.trace = function(){}

function td_G(){return Date.now();}
