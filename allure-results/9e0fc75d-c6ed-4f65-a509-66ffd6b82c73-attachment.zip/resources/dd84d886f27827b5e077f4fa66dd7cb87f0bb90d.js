var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_I6){self.testPort=td_I6.data[0];self.PortTestTimeOut=td_I6.data[1];td_h2();});var td_K0=function(td_s3){postMessage([self.OPEN,self.testPort]);};var td_EK=function(td_Il){var td_a5=td_G()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_a5]);};var td_lZ=function(td_LU){var td_HZ=td_G()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_HZ]);};function td_h2(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_K0;self.localWs.onerror=td_EK;self.localWs.onclose=td_lZ;self.localStartTime=td_G();setTimeout(td_dJ,5);}catch(td_Rz){tmx.debug(self.ERROR+self.SEP+td_Rz.message);
}}function td_dJ(){var td_tt=td_G()-self.localStartTime;if(self.localWs.readyState===0){if(td_tt>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_El();}else{setTimeout(function(){td_dJ();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_tt]);td_El();}}function td_El(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_G(){return Date.now();}
