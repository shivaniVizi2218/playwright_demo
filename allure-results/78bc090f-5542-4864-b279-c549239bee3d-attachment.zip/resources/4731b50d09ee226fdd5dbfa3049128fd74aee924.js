var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_T2){self.testPort=td_T2.data[0];self.PortTestTimeOut=td_T2.data[1];td_QI();});var td_l5=function(td_FG){postMessage([self.OPEN,self.testPort]);};var td_ez=function(td_Wq){var td_kA=td_b()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_kA]);};var td_Yp=function(td_Co){var td_J0=td_b()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_J0]);};function td_QI(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_l5;self.localWs.onerror=td_ez;self.localWs.onclose=td_Yp;self.localStartTime=td_b();setTimeout(td_ty,5);}catch(td_LA){tmx.debug(self.ERROR+self.SEP+td_LA.message);
}}function td_ty(){var td_d6=td_b()-self.localStartTime;if(self.localWs.readyState===0){if(td_d6>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_zV();}else{setTimeout(function(){td_ty();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_d6]);td_zV();}}function td_zV(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_b(){return Date.now();}
