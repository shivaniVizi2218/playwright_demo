var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_GG){self.testPort=td_GG.data[0];self.PortTestTimeOut=td_GG.data[1];td_LF();});var td_Y7=function(td_Ta){postMessage([self.OPEN,self.testPort]);};var td_PL=function(td_VM){var td_Ca=td_k()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_Ca]);};var td_dI=function(td_EV){var td_FU=td_k()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_FU]);};function td_LF(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_Y7;self.localWs.onerror=td_PL;self.localWs.onclose=td_dI;self.localStartTime=td_k();setTimeout(td_Mn,5);}catch(td_Wg){tmx.debug(self.ERROR+self.SEP+td_Wg.message);
}}function td_Mn(){var td_EX=td_k()-self.localStartTime;if(self.localWs.readyState===0){if(td_EX>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_cY();}else{setTimeout(function(){td_Mn();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_EX]);td_cY();}}function td_cY(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_k(){return Date.now();}
