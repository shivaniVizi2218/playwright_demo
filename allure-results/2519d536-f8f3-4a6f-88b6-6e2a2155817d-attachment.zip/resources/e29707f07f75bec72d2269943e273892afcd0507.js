var tmx = tmx || {}; //namespace
self.POSTMSGDONE = "DONE";
self.POSTMSGQUERY = "QUERY";
self.INIT = "INIT";
self.RESULT = "RESULT";
self.DATACOUNT = "DATACOUNT";
self.CTIMEOUT = "TIMEOUT";
self.MESSAGE = "message";
self.WOPEN = "watcher_open";
self.WERROR = "watcher_error";
self.WCLOSE = "watcher_close";
self.INTERVAL = "_interval";
self.NUMBER = "number";
self.SOCKET = "wss://127.0.0.1:";

self.pstMsg=null;self.isDone=false;self.count=-1;self.time=null;self.timeOut=5000;self.logFunc=null;self.addEventListener(self.MESSAGE,function(td_Wh){switch(td_Wh.data[0]){case self.INIT:self.count=td_Wh.data[1];
self.time=td_k();if(typeof(td_Wh.data[2])===self.NUMBER){self.timeOut=td_Wh.data[2];}break;case self.RESULT:if((td_Wh.data[1]<0)||(td_Wh.data[1]>=self.count)){self.isDone=true;postMessage([self.POSTMSGDONE,self.DATACOUNT]);
}else{if((self.time+self.timeOut)<td_k()){self.isDone=true;postMessage([self.POSTMSGDONE,self.CTIMEOUT]);}}break;default:break;}if(self.isDone===false){setTimeout(function(){},100);postMessage([self.POSTMSGQUERY]);
}});var td_nk=function(td_jG){postMessage([self.WOPEN,td_jG.toString()]);};var td_Bd=function(td_fw){postMessage([self.WERROR,td_fw.toString()]);};var td_iA=function(td_qJ){postMessage([self.WCLOSE,td_qJ.toString()]);
};
tmx.debug = function(){}

tmx.trace = function(){}

function td_k(){return Date.now();}
