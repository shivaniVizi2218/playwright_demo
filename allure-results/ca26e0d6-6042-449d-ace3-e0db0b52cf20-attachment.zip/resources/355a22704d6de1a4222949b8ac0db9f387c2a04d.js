var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_s2){self.testPort=td_s2.data[0];self.PortTestTimeOut=td_s2.data[1];td_gb();});var td_hE=function(td_V3){postMessage([self.OPEN,self.testPort]);};var td_Yp=function(td_G0){var td_Ng=td_E()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_Ng]);};var td_nJ=function(td_I5){var td_XE=td_E()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_XE]);};function td_gb(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_hE;self.localWs.onerror=td_Yp;self.localWs.onclose=td_nJ;self.localStartTime=td_E();setTimeout(td_Ck,5);}catch(td_zq){tmx.debug(self.ERROR+self.SEP+td_zq.message);
}}function td_Ck(){var td_Bu=td_E()-self.localStartTime;if(self.localWs.readyState===0){if(td_Bu>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_Va();}else{setTimeout(function(){td_Ck();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_Bu]);td_Va();}}function td_Va(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_E(){return Date.now();}
