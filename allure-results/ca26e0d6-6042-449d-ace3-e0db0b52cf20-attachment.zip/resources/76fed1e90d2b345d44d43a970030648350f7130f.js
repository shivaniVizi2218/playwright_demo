var tmx = tmx || {}; //namespace
self.POSTMSGDONE = "DONE";
self.POSTMSGQUERY = "QUERY";
self.INIT = "INIT";
self.RESULT = "RESULT";
self.DATACOUNT = "DATACOUNT";
self.CTIMEOUT = "TIMEOUT";
self.MESSAGE = "message";
self.WOPEN = "watcher_open";
self.WERROR = "watcher_error";
self.WCLOSE = "watcher_close";
self.INTERVAL = "_interval";
self.NUMBER = "number";
self.SOCKET = "wss://127.0.0.1:";

self.pstMsg=null;self.isDone=false;self.count=-1;self.time=null;self.timeOut=5000;self.logFunc=null;self.addEventListener(self.MESSAGE,function(td_D9){switch(td_D9.data[0]){case self.INIT:self.count=td_D9.data[1];
self.time=td_E();if(typeof(td_D9.data[2])===self.NUMBER){self.timeOut=td_D9.data[2];}break;case self.RESULT:if((td_D9.data[1]<0)||(td_D9.data[1]>=self.count)){self.isDone=true;postMessage([self.POSTMSGDONE,self.DATACOUNT]);
}else{if((self.time+self.timeOut)<td_E()){self.isDone=true;postMessage([self.POSTMSGDONE,self.CTIMEOUT]);}}break;default:break;}if(self.isDone===false){setTimeout(function(){},100);postMessage([self.POSTMSGQUERY]);
}});var td_Ff=function(td_wN){postMessage([self.WOPEN,td_wN.toString()]);};var td_eZ=function(td_Mp){postMessage([self.WERROR,td_Mp.toString()]);};var td_Me=function(td_gl){postMessage([self.WCLOSE,td_gl.toString()]);
};
tmx.debug = function(){}

tmx.trace = function(){}

function td_E(){return Date.now();}
