var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_dG){self.testPort=td_dG.data[0];self.PortTestTimeOut=td_dG.data[1];td_cG();});var td_f5=function(td_ES){postMessage([self.OPEN,self.testPort]);};var td_bR=function(td_EX){var td_LD=td_l()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_LD]);};var td_QS=function(td_EM){var td_H2=td_l()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_H2]);};function td_cG(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_f5;self.localWs.onerror=td_bR;self.localWs.onclose=td_QS;self.localStartTime=td_l();setTimeout(td_UD,5);}catch(td_Q9){tmx.debug(self.ERROR+self.SEP+td_Q9.message);
}}function td_UD(){var td_xu=td_l()-self.localStartTime;if(self.localWs.readyState===0){if(td_xu>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_Mf();}else{setTimeout(function(){td_UD();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_xu]);td_Mf();}}function td_Mf(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_l(){return Date.now();}
