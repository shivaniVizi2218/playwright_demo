var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_iQ){self.testPort=td_iQ.data[0];self.PortTestTimeOut=td_iQ.data[1];td_eQ();});var td_N5=function(td_gt){postMessage([self.OPEN,self.testPort]);};var td_Eq=function(td_Jv){var td_wE=td_L()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_wE]);};var td_q8=function(td_Ls){var td_Op=td_L()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_Op]);};function td_eQ(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_N5;self.localWs.onerror=td_Eq;self.localWs.onclose=td_q8;self.localStartTime=td_L();setTimeout(td_vq,5);}catch(td_fz){tmx.debug(self.ERROR+self.SEP+td_fz.message);
}}function td_vq(){var td_F6=td_L()-self.localStartTime;if(self.localWs.readyState===0){if(td_F6>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_Py();}else{setTimeout(function(){td_vq();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_F6]);td_Py();}}function td_Py(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_L(){return Date.now();}
