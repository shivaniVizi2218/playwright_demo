var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_cI){self.testPort=td_cI.data[0];self.PortTestTimeOut=td_cI.data[1];td_TJ();});var td_lB=function(td_o1){postMessage([self.OPEN,self.testPort]);};var td_Ln=function(td_tw){var td_Yh=td_o()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_Yh]);};var td_Bo=function(td_ts){var td_nl=td_o()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_nl]);};function td_TJ(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_lB;self.localWs.onerror=td_Ln;self.localWs.onclose=td_Bo;self.localStartTime=td_o();setTimeout(td_Ap,5);}catch(td_Fx){tmx.debug(self.ERROR+self.SEP+td_Fx.message);
}}function td_Ap(){var td_aN=td_o()-self.localStartTime;if(self.localWs.readyState===0){if(td_aN>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_EI();}else{setTimeout(function(){td_Ap();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_aN]);td_EI();}}function td_EI(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_o(){return Date.now();}
