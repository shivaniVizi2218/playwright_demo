var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_Yf){self.testPort=td_Yf.data[0];self.PortTestTimeOut=td_Yf.data[1];td_Lh();});var td_oM=function(td_ho){postMessage([self.OPEN,self.testPort]);};var td_nm=function(td_ce){var td_xY=td_U()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_xY]);};var td_jJ=function(td_lx){var td_Lc=td_U()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_Lc]);};function td_Lh(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_oM;self.localWs.onerror=td_nm;self.localWs.onclose=td_jJ;self.localStartTime=td_U();setTimeout(td_Y3,5);}catch(td_TW){tmx.debug(self.ERROR+self.SEP+td_TW.message);
}}function td_Y3(){var td_G9=td_U()-self.localStartTime;if(self.localWs.readyState===0){if(td_G9>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_sA();}else{setTimeout(function(){td_Y3();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_G9]);td_sA();}}function td_sA(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_U(){return Date.now();}
