var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_PB){self.testPort=td_PB.data[0];self.PortTestTimeOut=td_PB.data[1];td_uD();});var td_yz=function(td_LC){postMessage([self.OPEN,self.testPort]);};var td_JI=function(td_px){var td_Tt=td_P()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_Tt]);};var td_re=function(td_YB){var td_bR=td_P()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_bR]);};function td_uD(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_yz;self.localWs.onerror=td_JI;self.localWs.onclose=td_re;self.localStartTime=td_P();setTimeout(td_CE,5);}catch(td_fl){tmx.debug(self.ERROR+self.SEP+td_fl.message);
}}function td_CE(){var td_yd=td_P()-self.localStartTime;if(self.localWs.readyState===0){if(td_yd>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_kb();}else{setTimeout(function(){td_CE();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_yd]);td_kb();}}function td_kb(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_P(){return Date.now();}
