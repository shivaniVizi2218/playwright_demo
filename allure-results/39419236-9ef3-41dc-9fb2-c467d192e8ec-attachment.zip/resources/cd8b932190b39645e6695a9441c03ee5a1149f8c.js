var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_Ti){self.testPort=td_Ti.data[0];self.PortTestTimeOut=td_Ti.data[1];td_RF();});var td_ML=function(td_o4){postMessage([self.OPEN,self.testPort]);};var td_dP=function(td_C2){var td_zg=td_E()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_zg]);};var td_Bb=function(td_yO){var td_TH=td_E()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_TH]);};function td_RF(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_ML;self.localWs.onerror=td_dP;self.localWs.onclose=td_Bb;self.localStartTime=td_E();setTimeout(td_pF,5);}catch(td_OQ){tmx.debug(self.ERROR+self.SEP+td_OQ.message);
}}function td_pF(){var td_ds=td_E()-self.localStartTime;if(self.localWs.readyState===0){if(td_ds>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_nz();}else{setTimeout(function(){td_pF();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_ds]);td_nz();}}function td_nz(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_E(){return Date.now();}
