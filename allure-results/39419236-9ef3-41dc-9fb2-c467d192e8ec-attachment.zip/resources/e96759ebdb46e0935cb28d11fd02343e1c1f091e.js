var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_RA){self.testPort=td_RA.data[0];self.PortTestTimeOut=td_RA.data[1];td_E1();});var td_Qo=function(td_jY){postMessage([self.OPEN,self.testPort]);};var td_ec=function(td_oE){var td_O3=td_J()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_O3]);};var td_ty=function(td_ta){var td_fh=td_J()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_fh]);};function td_E1(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_Qo;self.localWs.onerror=td_ec;self.localWs.onclose=td_ty;self.localStartTime=td_J();setTimeout(td_kg,5);}catch(td_H2){tmx.debug(self.ERROR+self.SEP+td_H2.message);
}}function td_kg(){var td_wq=td_J()-self.localStartTime;if(self.localWs.readyState===0){if(td_wq>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_gm();}else{setTimeout(function(){td_kg();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_wq]);td_gm();}}function td_gm(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_J(){return Date.now();}
