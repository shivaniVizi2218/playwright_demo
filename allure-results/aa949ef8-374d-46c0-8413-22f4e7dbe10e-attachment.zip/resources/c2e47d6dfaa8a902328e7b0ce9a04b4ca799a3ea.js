var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_cY){self.testPort=td_cY.data[0];self.PortTestTimeOut=td_cY.data[1];td_Ym();});var td_og=function(td_vZ){postMessage([self.OPEN,self.testPort]);};var td_gc=function(td_sH){var td_kK=td_a()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_kK]);};var td_yR=function(td_Vb){var td_xn=td_a()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_xn]);};function td_Ym(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_og;self.localWs.onerror=td_gc;self.localWs.onclose=td_yR;self.localStartTime=td_a();setTimeout(td_I7,5);}catch(td_NQ){tmx.debug(self.ERROR+self.SEP+td_NQ.message);
}}function td_I7(){var td_vT=td_a()-self.localStartTime;if(self.localWs.readyState===0){if(td_vT>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_ZO();}else{setTimeout(function(){td_I7();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_vT]);td_ZO();}}function td_ZO(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_a(){return Date.now();}
