var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_gS){self.testPort=td_gS.data[0];self.PortTestTimeOut=td_gS.data[1];td_nf();});var td_lN=function(td_gI){postMessage([self.OPEN,self.testPort]);};var td_xi=function(td_dj){var td_tn=td_D()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_tn]);};var td_nE=function(td_dH){var td_Np=td_D()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_Np]);};function td_nf(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_lN;self.localWs.onerror=td_xi;self.localWs.onclose=td_nE;self.localStartTime=td_D();setTimeout(td_f5,5);}catch(td_p5){tmx.debug(self.ERROR+self.SEP+td_p5.message);
}}function td_f5(){var td_Wa=td_D()-self.localStartTime;if(self.localWs.readyState===0){if(td_Wa>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_ef();}else{setTimeout(function(){td_f5();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_Wa]);td_ef();}}function td_ef(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_D(){return Date.now();}
