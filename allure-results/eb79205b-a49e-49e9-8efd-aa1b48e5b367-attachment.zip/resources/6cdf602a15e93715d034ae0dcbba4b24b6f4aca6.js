var tmx = tmx || {}; //namespace
self.MESSAGE = "message";
self.OPEN = "open";
self.ERROR = "error";
self.CLOSE = "close";
self.INTERVAL = "_interval";
self.SOCKET = "wss://127.0.0.1:";
self.DATA = "DATA";
self.TIMEEXCEEDED = " - time exceeded";
self.SEP = " : ";

self.pstMsg=null;self.isDone=false;self.PortTestTimeOut=null;self.testPort=null;self.localStartTime=null;self.localWs=null;self.logFunc=null;
self.addEventListener(self.MESSAGE,function(td_XC){self.testPort=td_XC.data[0];self.PortTestTimeOut=td_XC.data[1];td_C0();});var td_qk=function(td_ku){postMessage([self.OPEN,self.testPort]);};var td_hp=function(td_Qy){var td_Of=td_n()-self.localStartTime;
postMessage([self.ERROR,self.testPort+self.INTERVAL,td_Of]);};var td_Tm=function(td_rD){var td_YE=td_n()-self.localStartTime;postMessage([self.CLOSE,self.testPort+self.INTERVAL,td_YE]);};function td_C0(){tmx.debug(self.testPort+self.SEP+self.PortTestTimeOut);
try{self.localWs=new WebSocket(self.SOCKET+self.testPort);self.localWs.onopen=td_qk;self.localWs.onerror=td_hp;self.localWs.onclose=td_Tm;self.localStartTime=td_n();setTimeout(td_UH,5);}catch(td_wf){tmx.debug(self.ERROR+self.SEP+td_wf.message);
}}function td_UH(){var td_lm=td_n()-self.localStartTime;if(self.localWs.readyState===0){if(td_lm>self.PortTestTimeOut){tmx.debug(self.testPort+self.TIMEEXCEEDED);postMessage([self.DATA,self.testPort+self.INTERVAL,self.PortTestTimeOut]);
td_TW();}else{setTimeout(function(){td_UH();},10);}}else{postMessage([self.DATA,self.testPort+self.INTERVAL,td_lm]);td_TW();}}function td_TW(){self.isDone=true;if(self.localWs!==null){self.localWs.close();
self.localWs=null;}}
tmx.debug = function(){}

tmx.trace = function(){}

function td_n(){return Date.now();}
